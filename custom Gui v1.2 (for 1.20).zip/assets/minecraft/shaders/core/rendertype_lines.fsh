#version 150

#moj_import <fog.glsl>

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform float GameTime;
uniform vec4 FogColor;

in float vertexDistance;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    if(vertexColor.r < 1.0 && vertexColor.g < 1.0 && vertexColor.b < 1.0 && vertexColor.a > 0.35 && vertexColor.a < 0.41) {
		float rainbowTime = GameTime * 4000;
		float redValue = sin(rainbowTime);
		float greenValue = sin(rainbowTime + 7.5);
		float blueValue = sin(rainbowTime + 15);
        fragColor = vec4(redValue * redValue, greenValue * greenValue, blueValue * blueValue, 1.0);
    } else {
        vec4 color = vertexColor * ColorModulator;
        fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
    }
}
